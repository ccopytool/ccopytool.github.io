/**
 * 소스에서 띄운 실행이 `Electron`이라는 이름과 아이콘으로 뜨지 않도록.
 *
 * macOS는 앱의 이름과 그림을 **돌고 있는 `.app` 번들**에서 읽습니다. `app.setName()`이 닿지 않는
 * 자리가 셋입니다: 메뉴 막대의 첫 항목(`CFBundleName`), 시스템 설정 › 알림에 뜨는 이름
 * (`CFBundleDisplayName`), 그리고 알림 권한이 저장되는 신원(`CFBundleIdentifier`). 아이콘도 같습니다 —
 * Dock은 켜진 뒤 `app.dock.setIcon()`으로 갈아입힐 수 있지만 앱 전환기(Cmd+Tab)와 실행 배너는
 * 번들의 `.icns`를 읽습니다.
 *
 * `pnpm start`나 `ccopy`로 띄운 실행에서 그 번들은 `node_modules`의 Electron 자신이므로, 넷 다
 * `Electron`이라고 답합니다. 그래서 그 번들을 제자리에서 고칩니다 — 묶어 배포하지 않고 고치는 길은
 * 이것뿐입니다.
 *
 * 여기서 안전한 이유는 그 번들이 ad-hoc(linker-signed)으로만 서명된 개발용이고 `Info.plist`가 서명에
 * 묶여 있지 않으며 리소스가 봉인되어 있지 않기 때문입니다. 다시 설치하면 원래대로 돌아가고, 그래서
 * 이 스크립트는 postinstall에서 함께 돕니다. `hungry`의 `scripts/brand-electron.mjs`에서 가져왔습니다.
 *
 * 실패는 실패가 아닙니다: 이름과 아이콘 때문에 설치가 멈추면 그건 훨씬 나쁜 거래입니다.
 *
 * 일부러 평범한 `.mjs`입니다 — Node는 `node_modules` 아래에서 TypeScript를 벗기지 않으므로 전역
 * 설치가 `.ts` 설치 스크립트를 돌릴 수 없습니다.
 */
import { copyFileSync, existsSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const root = dirname(here)

export const APP_NAME = 'ccopy'
/** 알림 권한이 이 이름으로 저장됩니다. 바뀌면 macOS는 새 앱으로 봅니다. */
export const APP_ID = 'app.ccopy'

const escapeXml = (value) => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')

/**
 * plist의 최상위 문자열 항목 하나를 고치고, 없으면 더합니다.
 *
 * `Info.plist`에서 우리가 볼 것은 평평한 `<dict>` 하나이므로, 겨냥한 자리만 고치면 나머지는 —
 * Electron 자신의 키들까지 — 바이트 그대로 남습니다.
 */
export const setPlistString = (plist, key, value) => {
  const escapedKey = escapeXml(key).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const entry = new RegExp(`(<key>${escapedKey}</key>\\s*<string>)([^<]*)(</string>)`)
  const match = entry.exec(plist)
  if (match) {
    if (match[2] === escapeXml(value)) return plist
    return plist.replace(entry, `$1${escapeXml(value)}$3`)
  }
  const closing = plist.lastIndexOf('</dict>')
  if (closing === -1) throw new Error('Info.plist에 넓힐 <dict>가 없습니다')
  return `${plist.slice(0, closing)}\t<key>${escapeXml(key)}</key>\n\t<string>${escapeXml(value)}</string>\n${plist.slice(closing)}`
}

/** 최상위 문자열 항목 하나를 읽습니다. 무엇이 바뀌었는지 적어 주기 위해. */
export const plistString = (plist, key) => {
  const escapedKey = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const match = new RegExp(`<key>${escapedKey}</key>\\s*<string>([^<]*)</string>`).exec(plist)
  return match ? match[1] : null
}

/** `electron` 패키지가 띄우는 `.app`, 아직 바이너리가 없으면 null. */
export const bundlePath = () => {
  try {
    const nodeRequire = createRequire(import.meta.url)
    const packageDir = dirname(nodeRequire.resolve('electron/package.json'))
    // `path.txt`는 번들 **안의 실행 파일**을 가리킵니다.
    const relative = readFileSync(join(packageDir, 'path.txt'), 'utf8').trim()
    const marker = relative.indexOf('.app/')
    if (marker === -1) return null
    const bundle = join(packageDir, 'dist', relative.slice(0, marker + 4))
    return statSync(bundle).isDirectory() ? bundle : null
  } catch {
    return null
  }
}

const sameFile = (a, b) => {
  try {
    return readFileSync(a).equals(readFileSync(b))
  } catch {
    return false
  }
}

/** 이름 셋과 아이콘을 이 앱의 것으로. 바뀐 것마다 한 줄씩 돌려줍니다. */
export const brand = () => {
  if (process.platform !== 'darwin') return []
  const bundle = bundlePath()
  if (!bundle) return []

  const changes = []
  const plistFile = join(bundle, 'Contents/Info.plist')
  const before = readFileSync(plistFile, 'utf8')

  let after = before
  for (const [key, value] of [
    ['CFBundleName', APP_NAME],
    ['CFBundleDisplayName', APP_NAME],
    ['CFBundleIdentifier', APP_ID]
  ]) {
    const current = plistString(after, key)
    after = setPlistString(after, key, value)
    if (current !== value) changes.push(`${key}: ${current ?? '(없음)'} → ${value}`)
  }
  if (after !== before) writeFileSync(plistFile, after, 'utf8')

  // 배너와 앱 전환기는 번들에서 아이콘을 읽습니다. `app.dock.setIcon()`이 닿지 않는 자리입니다.
  const source = join(root, 'resources/icon.icns')
  const iconName = plistString(after, 'CFBundleIconFile') ?? 'electron.icns'
  const target = join(bundle, 'Contents/Resources', iconName.endsWith('.icns') ? iconName : `${iconName}.icns`)
  if (existsSync(source) && existsSync(target) && !sameFile(source, target)) {
    copyFileSync(source, target)
    changes.push(`${iconName}: resources/icon.icns로 바꿨습니다`)
  }

  return changes
}

const runningAsScript = () => {
  const entry = process.argv[1]
  return typeof entry === 'string' && pathToFileURL(entry).href === import.meta.url
}

if (runningAsScript()) {
  try {
    for (const change of brand()) console.log(`[${APP_NAME}] ${change}`)
  } catch (error) {
    console.warn(`[${APP_NAME}] 번들을 고치지 못했습니다 (${error instanceof Error ? error.message : String(error)})`)
  }
}
