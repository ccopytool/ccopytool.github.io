/**
 * Install-time setup: the Electron binary.
 *
 * The `electron` package ships no runtime — it downloads a ~110MB zip for this
 * platform and unpacks it. Doing that here only moves the wait out of the first
 * launch, and nothing here is load-bearing: npm 12 blocks dependency lifecycle
 * scripts unless they are allow-listed, so a global install may never run this
 * file at all. That is why `bin/ccopy.mjs` calls the same `ensureElectron` on
 * first run — an install whose scripts were blocked repairs itself instead of
 * handing back an instruction to type.
 *
 * Plain `.mjs` on purpose: Node refuses to strip TypeScript under `node_modules`,
 * so a global install cannot run a `.ts` install script.
 *
 * Adapted from `hungry`'s `scripts/postinstall.mjs`, minus the parts that were
 * about its native addon and its macOS branding.
 */
import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync, rmSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const nodeRequire = createRequire(import.meta.url)

/** The installed directory of a package, or null when it cannot be resolved. */
export const packageDir = (name) => {
  try {
    return dirname(nodeRequire.resolve(`${name}/package.json`))
  } catch {
    return null
  }
}

/**
 * The Electron executable this install would launch, or null when the binary has
 * not been downloaded yet. `path.txt` is written by Electron's own installer.
 */
export const electronBinary = () => {
  const dir = packageDir('electron')
  if (!dir) return null
  try {
    const binary = join(dir, 'dist', readFileSync(join(dir, 'path.txt'), 'utf8').trim())
    return existsSync(binary) ? binary : null
  } catch {
    return null
  }
}

/**
 * Removes a `dist` left behind by an extraction that did not finish.
 *
 * Electron's `install.js` unzips straight into `dist` and never clears it first,
 * so an install interrupted mid-extract leaves files the next one cannot write
 * over. On macOS the first casualty is a symlink inside the framework and the
 * install dies with `EEXIST: … symlink 'Versions/Current/Electron Framework'`.
 * Retrying changes nothing — the leftovers are still there — so the install stays
 * broken until somebody deletes the directory by hand. That is the step being
 * automated.
 *
 * Only called once the binary is known to be missing, which is what makes it
 * safe: a `dist` with no runnable binary in it is the wreck of a previous
 * attempt. It is entirely `install.js` output and is in no tarball.
 */
export const clearStaleDist = (dir) => {
  // With an override, `dist` is not where the binary comes from and not ours.
  if (process.env['ELECTRON_OVERRIDE_DIST_PATH']) return { removed: false, detail: 'overridden' }

  const dist = join(dir, 'dist')
  if (!existsSync(dist)) return { removed: false, detail: 'nothing to clear' }

  try {
    rmSync(dist, { recursive: true, force: true })
    return { removed: true, detail: dist }
  } catch (error) {
    // Typically an install owned by another user (`sudo npm i -g`, run as someone
    // else). Say which directory, since that is the whole fix.
    return { removed: false, detail: error instanceof Error ? error.message : String(error) }
  }
}

const MB = 1024 * 1024

// Return to column 0 and clear the line, so a rewrite cannot leave the tail of a
// longer line standing to the right of a shorter one.
const ERASE_LINE = '\u001b[2K\r'

/**
 * Turns a download's progress events into the exact text to write, or null for
 * the ones not worth saying out loud.
 *
 * There are about a thousand for one Electron zip, so most are dropped, and how
 * they are dropped depends on where the words go. A terminal gets one line
 * rewritten in place, often enough to look live. Anywhere else — every
 * `pnpm install`, where the output is a pipe — a carriage return is a character
 * rather than a cursor movement, so the same treatment would leave a thousand
 * lines in someone's log; there it reports each tenth of the file on its own line.
 *
 * It returns the bytes rather than a description of them so the escapes are
 * covered by the check too.
 */
export const downloadProgress = ({ tty, everyMs = 200 }) => {
  let reported = -10
  // Not 0: the pacing is "not again for 200ms", and starting the clock at the
  // epoch would hold back the first event — the one saying the wait has begun.
  let at = -Infinity
  let dangling = false

  return {
    line: (progress, now) => {
      // The first event arrives before the response headers, with no total in it.
      // There is nothing to be a percentage of yet.
      const total = progress.total
      if (!total) return null

      const percent = Math.floor((progress.percent ?? 0) * 100)
      const done = percent >= 100
      if (percent === reported && !done) return null
      if (done && reported === 100) return null

      if (tty) {
        if (!done && now - at < everyMs) return null
        at = now
      } else if (!done && percent < reported + 10) {
        return null
      }

      reported = percent
      const read = (progress.transferred / MB).toFixed(0)
      const size = (total / MB).toFixed(0)
      const text = `Electron runtime: ${percent}% (${read}/${size} MB)`

      if (!tty) return `${text}\n`
      dangling = !done
      return `${ERASE_LINE}${text}${done ? '\n' : ''}`
    },
    close: () => {
      const ending = dangling ? '\n' : ''
      dangling = false
      return ending
    }
  }
}

/**
 * Fetches the Electron zip into the cache `install.js` reads from, saying how far
 * along it is.
 *
 * `install.js` downloads it silently: `@electron/get` holds its own progress bar
 * back for a fixed 30 seconds and then writes nothing unless the stream is a
 * terminal — which under `pnpm install` it is not. A hundred megabytes over a home
 * connection is minutes of a cursor that does not move, and the first thing anyone
 * does to a hung install is kill it, which is how `dist` ends up half-extracted.
 *
 * There is no way to ask `install.js` to report, so the fetch happens here with the
 * parameters it would have used, into the cache it looks in — leaving it the
 * extraction. Getting those parameters wrong costs a second download rather than a
 * wrong one, and `check-install.ts` pins them against the installed `install.js`.
 *
 * Additive by construction: every failure returns rather than throws, and the
 * caller goes on to `install.js`, which downloads exactly as it did before.
 */
export const fetchElectron = async (dir, write) => {
  const progress = downloadProgress({ tty: Boolean(write.isTTY) })
  try {
    const electronRequire = createRequire(join(dir, 'package.json'))
    const { downloadArtifact } = electronRequire('@electron/get')

    const platform = process.env['npm_config_platform'] || process.platform
    let arch = process.env['npm_config_arch'] || process.arch
    if (
      platform === 'darwin' &&
      process.platform === 'darwin' &&
      arch === 'x64' &&
      process.env['npm_config_arch'] === undefined
    ) {
      // An x64 Node under Rosetta should still get the arm64 runtime.
      try {
        const translated = spawnSync('sysctl', ['-in', 'sysctl.proc_translated'], { encoding: 'utf8' })
        if (translated.stdout?.trim() === '1') arch = 'arm64'
      } catch {
        // Not translated, or no sysctl: x64 is the right answer either way.
      }
    }

    const remoteChecksums =
      process.env['electron_use_remote_checksums'] || process.env['npm_config_electron_use_remote_checksums']

    const zip = await downloadArtifact({
      version: electronRequire('./package.json').version,
      artifactName: 'electron',
      force: process.env['force_no_cache'] === 'true',
      cacheRoot: process.env['electron_config_cache'],
      checksums: remoteChecksums ? undefined : electronRequire('./checksums.json'),
      platform,
      arch,
      downloadOptions: {
        getProgressCallback: (event) => {
          const line = progress.line(event, Date.now())
          if (line) write.write(line)
        }
      }
    })
    return { ok: true, detail: zip }
  } catch (error) {
    return { ok: false, detail: error instanceof Error ? error.message : String(error) }
  } finally {
    write.write(progress.close())
  }
}

/** Downloads and unpacks the Electron binary unless it is already there. */
export const ensureElectron = async ({ write = process.stderr } = {}) => {
  const existing = electronBinary()
  if (existing) return { ok: true, detail: existing }

  const dir = packageDir('electron')
  if (!dir) return { ok: false, detail: 'the electron package is not installed' }

  const stale = clearStaleDist(dir)
  if (stale.removed) write.write(`[ccopy] cleared a half-extracted Electron: ${stale.detail}\n`)

  // Into the cache install.js reads from, so the silent part is over before it
  // starts. A failure here is not one: install.js downloads it itself.
  await fetchElectron(dir, write)

  // Unpacking is the rest of the wait, and install.js says nothing during it.
  write.write('[ccopy] unpacking the Electron runtime…\n')

  const result = spawnSync(process.execPath, [join(dir, 'install.js')], { stdio: 'inherit' })
  const binary = electronBinary()
  if (result.status === 0 && binary) return { ok: true, detail: binary }

  const reason = result.error?.message ?? `install.js exited with ${result.status ?? 'no status'}`
  return { ok: false, detail: stale.removed ? reason : `${reason} (${stale.detail})` }
}

const runningAsScript = () => {
  const entry = process.argv[1]
  return typeof entry === 'string' && pathToFileURL(entry).href === import.meta.url
}

if (runningAsScript()) {
  if (process.env['CCOPY_SKIP_POSTINSTALL'] === '1') {
    console.log('[ccopy] CCOPY_SKIP_POSTINSTALL=1, skipping install-time setup')
    process.exit(0)
  }

  const electron = await ensureElectron()
  if (electron.ok) {
    console.log(`[ccopy] Electron binary ready: ${electron.detail}`)
  } else {
    console.warn(
      `[ccopy] could not download the Electron binary now (${electron.detail}).\n` +
        '[ccopy] it is downloaded again on the first `ccopy` run.'
    )
  }

  // A warm-up must never be the reason an install fails.
  process.exit(0)
}
